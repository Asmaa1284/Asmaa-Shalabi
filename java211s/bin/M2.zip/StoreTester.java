package java211s;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class StoreTester {
	public static void main(String[]args) {
		ArrayList<Perishable> perishable= new ArrayList<>();
		Perishable c2= new CannedFood("tomato ", 2.5f, "09-12-2025", "09-12-2020", "segnature");
		Perishable c1= new CannedFood("yogurt", 3.5f, "09-14-2025", "09-14-2020", "segnature");
		
		
		perishable.add(c2);
		perishable.add(c1);
		System.out.println(perishable);
		
		System.out.println(perishable.toString());
		System.out.println(c2.comparTo(c1));
		Collections.sort(perishable);
		System.out.println(perishable);
		
	}

}
