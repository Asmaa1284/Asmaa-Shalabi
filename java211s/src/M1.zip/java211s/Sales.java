
import java.util.ArrayList;
import java.util.Objects;

public class Sales extends Employee{
	private ArrayList<String> items= new ArrayList<>();

	public Sales(int id, String name) {
		super(id, name);
		
	}

	public Sales(String name) {
		super(name);
		
	}

	public ArrayList<String> getItems() {
		return items;
	}

	public void setItems(ArrayList<String> items) {
		if(items.size()>0) {
		this.items = items;
		}
	}

	@Override
	public String toString() {
		String s = super.toString();
		s += "Sales [items=" + items + "]";
		return s;
	}

	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sales other = (Sales) obj;
		return Objects.equals(items, other.items);
	}


}
