package java211s;

import java.util.Objects;

public class Employee {
  private int id;
  private String name;
  private static final int DEFAULT_ID = 0;

public Employee(int id, String name) {

	this.id = id;
	this.name = name;
}
public Employee(String name) {
	
	this( DEFAULT_ID,name);
	
}
public int getId() {
	return id;
}
public void setId(int id) {
	if(id >= 0) {
	this.id = id;
	}
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public String toString() {
	return this.name +" (id =" + id + ")";
}

@Override
public boolean equals(Object obj) {
	boolean isEquals;
	
	if (obj instanceof Employee) {
		 
		Employee nE= (Employee)obj;
		
		int nId= nE.getId();
		String nName= nE.getName();
		if((id==nId) &&( name.equalsIgnoreCase(nName))) {
		
			isEquals= true;
		}else {
			isEquals= false;
		}
	
     }else {
    	 
	isEquals= false;
	}
	return isEquals;
}


}
