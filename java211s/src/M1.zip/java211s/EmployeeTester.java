package java211s;

import java.util.ArrayList;

public class EmployeeTester {

	public static void main(String[] args) {
		 ArrayList<Employee> e= new ArrayList<>();
		 ArrayList<Customer> c= new ArrayList<>();
		Employee employee1= new Employee(123,"Ahmed");
		Employee employee2= new Employee("Aycil");
		Employee employee3= new Employee(65,"Ahmed");
		Admin admin= new Admin(111,"Asmaa");
		Admin admin2= new Admin(121,"Asmaa");
		Sales sale1= new Sales(222,"Ehab");
		e.add(employee1);
		e.add(employee2);
		e.add(employee3);
		e.add(admin);
		e.add(sale1);
		Customer c1= new Customer("Ahmed","12345");
		Customer c2= new Customer("Aycil","0000");
		Customer c3= new Customer("Asmaa","5555");
		c.add(c1);
		c.add(c2);
		c.add(c3);
		System.out.println(c.toString());
		System.out.println(admin.equals(admin2));
		System.out.println("id is "+ employee1.getId());
		System.out.println("id is "+ employee2.getId());
		employee1.setId(-65);
		System.out.println("id is "+ employee1.getId());
		System.out.println("id is "+ employee2.getId());
		employee1.setId(65);
		System.out.println("id is "+ employee1.getId());
		System.out.println("id is "+ employee2.getId());
		System.out.println(employee1);
		System.out.println(employee2);
		System.out.println(employee1.equals(employee2));
		System.out.println(employee3.equals(employee1));
		System.out.println(admin.addEmployee(employee1));
		admin.review();
		
	}

}
