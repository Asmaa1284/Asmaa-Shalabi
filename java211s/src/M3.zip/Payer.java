

public interface Payer {    // M3 USING STRATEGY
 void pay();
}
