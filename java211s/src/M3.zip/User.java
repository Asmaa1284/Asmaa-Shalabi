

public interface User {   // M3 USING STRATEGY
	void logIn();

}
